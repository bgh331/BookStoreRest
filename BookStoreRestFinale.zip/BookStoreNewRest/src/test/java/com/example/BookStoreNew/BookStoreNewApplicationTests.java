package com.example.BookStoreNew;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookStoreNewApplicationTests {

	@Test
	void contextLoads() {
	}

}
